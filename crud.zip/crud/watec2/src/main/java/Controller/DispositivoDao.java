package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Model.Dispositivo;
import Model.Conexao;

public class DispositivoDao {
	
	private Connection conn = null;
	private String sql = "";
	private PreparedStatement ps;
	
	public void cadastrocll(Dispositivo dispositivo) {
		sql = "INSERT INTO dispositivos (marca, modelo, imei, problema) VALUES(?,?,?,?)";
		
		try{
			conn = Conexao.getConn();
			ps = conn.prepareStatement(sql);
			ps.setString(1, dispositivo.getMarca());
			ps.setString(2, dispositivo.getModelo());
			ps.setString(3, dispositivo.getImei());
			ps.setString(4, dispositivo.getProblema());
			ps.execute();
			ps.close();
		}catch(SQLException e) {
			System.out.println("Erro ao inserir "+e.getMessage());
		}
	}
}
