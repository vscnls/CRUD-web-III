package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
	public static void main(String[] args) {
		getConn();
	}
	
	public static Connection getConn() {
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tabela", "root", "");
		}catch(ClassNotFoundException error) {
			System.out.println("Erro"+error.getMessage());
	
		}catch (SQLException e) {
			System.out.println("deu erro 🤣");
		}
		return conn;
	}
	
}
